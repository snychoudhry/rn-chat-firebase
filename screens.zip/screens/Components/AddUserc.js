import React, {useState, useEffect, useCallback} from 'react';
import {
  View,
  Modal,
  TouchableOpacity,
  StyleSheet,
  Text,
  FlatList,
} from 'react-native';
import Pdf from 'react-native-pdf';
import Video from 'react-native-video';
import Icon from 'react-native-vector-icons/Ionicons';
import firestore from '@react-native-firebase/firestore';

function AddUserc({visible, props, groupId, onClose}) {
  const [userMembers, setuserMembers] = useState([]);
  const [selected, setSelected] = useState([]);
  useEffect(() => {
    async function onResult(QuerySnapshot) {
      try {
        const addedusers = await firestore()
          .collection('THREADS')
          .doc(groupId)
          .get();
        const allUsers = QuerySnapshot.docs.map(docSnap => docSnap.data());
        const filteredUsers = allUsers.filter(
          element => !addedusers.data().members.includes(element.uid),
        );
        setuserMembers(filteredUsers);
      } catch (error) {
        console.log('docSanp==', error);
      }
    }
    const unsubscribe = firestore()
      .collection('users')
      .where('uid', '!=', props.uid)
      .onSnapshot(onResult);
    return () => unsubscribe;
  }, [visible]);

  const addMemberToGroup = async () => {
    onClose();
    if (selected.length > 0) {
      try {
        const groupRef = firestore().collection('THREADS').doc(groupId);
        await groupRef.update({
          //   members: firestore.FieldValue.arrayUnion(...selected),
          members: firestore.FieldValue.arrayUnion(...selected),
        });
        await groupRef.collection('messages').add({
          _id: new Date(),
          text: `${props.email} have added ${selected.length} members to the group.`,
          createdAt: new Date(),
          system: true,
        });
        setSelected([]);
        console.log('User added to the group successfully!');
      } catch (error) {
        console.error('Error adding user to the group:', error);
      }
    } else {
      onClose();
    }
  };

  const selectMemeber = id => {
    const index = selected.indexOf(id);
    console.log('index   ', index); // Check if ID exists in the array
    if (index === -1) {
      setSelected([...selected, id]);
    } else {
      const updatedSelected = selected.filter(itemId => itemId !== id);
      setSelected(updatedSelected);
    }
  };
  const renderCheckIcon = useCallback(
    id => {
      if (selected.indexOf(id) !== -1)
        return (
          <Icon
            name="checkmark-circle"
            color={'#009387'}
            size={30}
            onPress={onClose}
          />
        );
    },
    [selected],
  );
  console.log(props);
  return (
    <Modal
      visible={visible}
      onRequestClose={onClose}
      transparent={true}
      animationType="slide"
      style={{height: 400}}>
      <View style={styles.container}>
        {/* <Icon
          name="close-circle-outline"
          color={'#009387'}
          size={30}
          onPress={() => {
            onClose();
            setSelected([]);
          }}
          style={{alignSelf: 'flex-end', padding: 10}}
        /> */}
        <View style={{flex: 1, marginTop: 15}}>
          {userMembers.length > 0 ? (
            <FlatList
              data={userMembers}
              keyExtractor={item => item.uid}
              renderItem={({item}) => (
                <TouchableOpacity onPress={() => selectMemeber(item.uid)}>
                  <View style={styles.card}>
                    <View style={{flexDirection: 'row'}}>
                      <View style={styles.userImageST}>
                        <Icon
                          style={{alignSelf: 'center'}}
                          name={'person'}
                          size={25}
                          color={'white'}
                        />
                      </View>
                      <View style={styles.textArea}>
                        <Text style={styles.nameText}>{item.name}</Text>
                        <Text style={styles.msgContent}>{item.email}</Text>
                      </View>
                    </View>
                    {renderCheckIcon(item.uid)}
                  </View>
                </TouchableOpacity>
              )}
            />
          ) : (
            <Text style={{alignSelf: 'center', color: 'black'}}>
              No User Found
            </Text>
          )}
        </View>

        <Icon
          name="checkmark-sharp"
          color={'white'}
          size={30}
          onPress={addMemberToGroup}
          style={styles.iconStyle}
        />
      </View>
    </Modal>
  );
}
export default AddUserc;
const styles = StyleSheet.create({
  buttonCancel: {
    width: 35,
    height: 35,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    borderColor: 'black',
    left: 13,
  },
  card: {
    width: '90%',
    height: 'auto',
    marginHorizontal: 4,
    marginVertical: 6,
    flexDirection: 'row',
  },
  userImageST: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignSelf: 'center',
    backgroundColor: '#009387',
    justifyContent: 'center',
  },
  textArea: {
    flexDirection: 'column',
    justifyContent: 'center',
    padding: 5,
    paddingLeft: 10,
    width: 300,
    backgroundColor: 'transparent',
    borderBottomWidth: 1,
    borderBottomColor: '#cccccc',
  },
  nameText: {
    fontSize: 14,
    fontWeight: '900',
    fontFamily: 'Verdana',
    color: 'black',
  },
  container: {
    height: '70%',
    width: '100%',
    marginTop: 25,
    backgroundColor: 'white',
    position: 'absolute',
    bottom: 0,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
  },
  msgContent: {
    paddingTop: 5,
    color: 'black',
  },

  iconStyle: {
    alignSelf: 'flex-end',
    position: 'absolute',
    bottom: 25,
    right: 30,
    backgroundColor: '#009387',
    padding: 10,
    borderRadius: 5,
  },
});
